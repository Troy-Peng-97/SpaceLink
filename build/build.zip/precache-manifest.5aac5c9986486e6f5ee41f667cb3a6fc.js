self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "14575524b10b22d1e13d331e5e583ffb",
    "url": "/index.html"
  },
  {
    "revision": "cd324b3ae74e1b5beb3f",
    "url": "/static/css/2.48db8b0f.chunk.css"
  },
  {
    "revision": "0c6b0f12b5b741a410cc",
    "url": "/static/css/main.2903d8b6.chunk.css"
  },
  {
    "revision": "cd324b3ae74e1b5beb3f",
    "url": "/static/js/2.463c64bc.chunk.js"
  },
  {
    "revision": "3453b8997016469371284a28c0e873e2",
    "url": "/static/js/2.463c64bc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0c6b0f12b5b741a410cc",
    "url": "/static/js/main.4305d448.chunk.js"
  },
  {
    "revision": "05567713dd457e4a83d8",
    "url": "/static/js/runtime-main.676014ac.js"
  },
  {
    "revision": "141ccf71d7c4a352123d5d70c62a6d96",
    "url": "/static/media/satellite.141ccf71.svg"
  },
  {
    "revision": "28756d25bf99fa84e7a1e4f6af346faf",
    "url": "/static/media/starlink_logo.28756d25.svg"
  }
]);